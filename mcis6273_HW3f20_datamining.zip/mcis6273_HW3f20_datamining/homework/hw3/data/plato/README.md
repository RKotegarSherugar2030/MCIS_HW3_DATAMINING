pg1497 The Republic
pg1600 Symposium
pg1656 Apology
pg1750 Laws