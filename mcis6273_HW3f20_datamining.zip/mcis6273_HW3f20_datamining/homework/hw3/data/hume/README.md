pg10574.txt   The History of England, Volume I
pg36120.txt   Essays
pg4705.txt    A Treatise of Human Nature

===
pg59792-0.txt  Hume's Political Discourses
pg62856-0.txt  A Treatise of Human Nature Being an Attempt to Introduce the Experimental Method into Moral Subjects

===

1616
Title: Cratylus
Author: Plato

1635
Title: Ion
Author: Plato


1726
Title: Theaetetus
Author: Plato

1735
Title: Sophist
Author: Plato