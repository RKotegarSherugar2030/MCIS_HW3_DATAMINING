===

pg26095.txt  The Athenian Constitution by Aristotle
pg6763.txt   Poetics by Aristotle
pg8438.txt   Ethics

===

pg6762.txt   Politics: A Treatise on Government
pg2412.txt   Categoriae
pg59058.txt  Aristotle's History of Animals In Ten Books